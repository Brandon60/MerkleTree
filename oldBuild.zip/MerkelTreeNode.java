public class MerkelTreeNode extends Node {
    private MerkelTreeNode left;
    private MerkelTreeNode right;

    public MerkelTreeNode() {
        left = null;
        right = null;
    }

    public MerkelTreeNode(MerkelTreeNode leftNode, MerkelTreeNode rightNode) {
        left = leftNode;
        right = rightNode;
    }

    public MerkelTreeNode getLeft() {
        return left;
    }

    public void setLeft(MerkelTreeNode node) {
        left = node;
    }

    public MerkelTreeNode getRight() {
        return right;
    }

    public void setRight(MerkelTreeNode node) {
        right = node;
    }

    @Override
    public int computeHash() {
        String combinedHash = "" + getLeft().getHash() + getRight().getHash();

        // Hashing function
        int hash = combinedHash.hashCode();

        return hash;
    }
}
