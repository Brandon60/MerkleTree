
public abstract class Node {
	private int hash = 0;
	
	public abstract int computeHash();
	
	public int getHash() {return hash;}
	public void setHash(int hash) {
		this.hash = hash;
	}
}
