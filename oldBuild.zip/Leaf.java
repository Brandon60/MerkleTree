public class Leaf extends Node {
    private String data;

    public Leaf() {
        data = "";
    }

    public Leaf(String data) {
        this.data = data;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    @Override
    public int computeHash() {
        int hash = getData().hashCode();
        return hash;
    }
}