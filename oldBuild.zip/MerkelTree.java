
import java.util.*;

public class MerkelTree {
	MerkelTreeNode root;
	
	public MerkelTreeNode getRoot() {return root;}
	public void setRoot(MerkelTreeNode root) {this.root = root;}
	
	// contructs tree
	public void construct(Queue<String> data) {
		
		if(data.size() == 1) {
			Leaf newLeaf = new Leaf(data.poll());
			root.setHash(newLeaf.computeHash());
		}
		else {
			if(data.size() % 2 != 0) {
				data.add("empty");
			}
			Queue<String> copyData = data;
			Queue<Integer> hashData = new LinkedList<>();
			Queue<MerkelTreeNode> merkelQ = new LinkedList<>();
			// converts all data into hashes
			while(copyData.peek() != null) {
				Leaf newLeaf = new Leaf(copyData.poll());
				hashData.add(newLeaf.computeHash());
				// converting hashes into merkel tree nodes
				while(hashData.peek() != null) {
					MerkelTreeNode newNode = new MerkelTreeNode();
					newNode.setHash(hashData.poll());
					merkelQ.add(newNode);
				}
			}
			while(merkelQ.size() != 1) {
				MerkelTreeNode x = new MerkelTreeNode();
				x.setLeft(merkelQ.poll());
				x.setRight(merkelQ.poll());
				x.setHash(x.computeHash());
				merkelQ.add(x);
			}
			root = merkelQ.poll();
		}
		
	}
	public boolean find(String data) {
		Leaf newLeaf = new Leaf(data);
		int lookFor = newLeaf.computeHash();
		MerkelTreeNode rootNode = this.root;
		return findHelper(lookFor, rootNode);
	}
	public boolean findHelper(int findHash, MerkelTreeNode curr) {
		if(curr.getHash() == findHash) {
			return true;
		}
		if(curr.getLeft() != null) {
			findHelper(findHash, curr.getLeft());
		}
		if(curr.getRight() != null) {
			findHelper(findHash, curr.getRight());
		}
		return false;
	}
	
	public void printTree() {
		
	}
	
	public boolean removeData(String data) {
		return true;
	}
}
